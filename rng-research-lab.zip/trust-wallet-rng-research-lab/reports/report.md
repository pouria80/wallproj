# گزارش تحقیق — CVE-2023-31290 / GHSA-pm4f-pggw-8jwc — Trust Wallet wallet-core WASM RNG

- ابزار: `rng_research` نسخه 1.0.0
- یادداشت جداسازی مشاهدات: 'real-evidence' runs operate on byte-exact upstream snapshots; 'modelling' runs are synthetic demonstrations; 'security-fix' runs exercise real CSPRNGs. Do not conflate categories.

## دفتر شواهد

مجموع رکوردها: **12** — `confirmed`: 9, `needs_more_access`: 1, `partially_confirmed`: 2

| ادعا | منبع اولیه | فایل/خط یا commit | روش راستی‌آزمایی | وضعیت | میزان اطمینان |
|---|---|---|---|---|---|
| CVE-2023-31290 (GHSA-pm4f-pggw-8jwc) affects Trust Wallet Core before 3.1.1, as used in the Trust Wallet browser extension versions 0.0.172 through 0.0.182; root cause is 32-bit entropy from mt19937 seeded with a single 32-bit value. | https://github.com/advisories/GHSA-pm4f-pggw-8jwc | advisory GHSA-pm4f-pggw-8jwc / CVE-2023-31290; CVSS 5.9 vector CVSS:3.1/AV:N/AC:H/PR:N/UI:N/S:U/C:N/I:H/A:N | Fetched advisory JSON live from api.github.com on 2026-10-12; saved verbatim at fixtures/source-snapshots/GHSA-pm4f-pggw-8jwc.json | تأییدشده (confirmed) | high |
| The vulnerable RNG for the WASM build lived in wasm/src/Random.cpp and constructed a fresh std::mt19937 per call seeded by std::random_device{}() in both random32() and random_buffer(). | https://github.com/trustwallet/wallet-core | wasm/src/Random.cpp @ commit 69b2da9826dfdeb8116be1e5a3747b3e9418592d (lines 13-19) | Downloaded byte-exact file at that commit via raw.githubusercontent.com; sha256 f8dea1b9bd1e7057a0f7166ef372e3b34fc4a96eb7fa9e31bbd137beb8c5aab1 stored in fixtures/source-snapshots/ | تأییدشده (confirmed) | high |
| Fix commit d3c2eee16b154cbb69e8959b01e5e71fbabb1212 ('[emscripten]: use javascript for random generation (#2750)', 2022-11-21) replaced the C++ <random> usage with EM_ASM bridges to crypto.getRandomValues (browser) and Node crypto.randomBytes, failing closed otherwise. | https://github.com/trustwallet/wallet-core/commit/d3c2eee16b154cbb69e8959b01e5e71fbabb1212 | commit d3c2eee16b15..., parent 69b2da9826df..., only file changed: wasm/src/Random.cpp | Commit metadata + diff fetched from GitHub API on 2026-10-12; post-fix file downloaded at same commit (sha256 609bb7543f9d0d1200f7e62c69c428e805b5e2b4600ece2e60656216ae7f096f); local diff of the two snapshots saved as fixtures/patches/d3c2eee16b15.diff | تأییدشده (confirmed) | high |
| The fix commit is tagged as release 3.1.1, matching the advisory's 'before 3.1.1' boundary. | https://github.com/trustwallet/wallet-core/tags | tag 3.1.1 -> commit d3c2eee16b15...; tag 3.1.0 -> commit efca5eeef5ab... | Tag listing retrieved via API pages 1-6 on 2026-10-12; tag->sha mapping recorded in docs/historical-source-analysis.md | تأییدشده (confirmed) | high |
| wasm/src/Random.cpp was introduced by commit 5b8beb939d08b2b252afff72aeb1388a95d1de19 ('Add Random for wasm (#2240)', 2022-05-24) already containing the mt19937 pattern; content identical through v3.0.0..3.1.0. | https://api.github.com/repos/trustwallet/wallet-core/commits?path=wasm/src/Random.cpp | commit 5b8beb939d08...; verified identical text also at tag 3.0.0 (200bd11232c4...) | Path history via commits API + raw file fetch at tag 3.0.0 compared visually/by hash | تأییدشده (confirmed) | high |
| Effective mnemonic entropy of wallets created by the affected extension builds is bounded by ~32 bits (~4.3 billion possible mnemonics), versus 128+ bits expected from BIP-39. | https://github.com/advisories/GHSA-pm4f-pggw-8jwc + code analysis | random_buffer() fed 16 bytes of entropy to mnemonic generation while each byte stream derives from one 32-bit seed (mt19937 reseeded per call) | Advisory states it explicitly; our static analysis confirms the per-call reseeding structure; modelling experiment E2 reproduces the state-space collapse mechanism synthetically | تا حدی تأییدشده (partially_confirmed) | medium |
| In the vulnerable Emscripten builds, std::random_device was additionally weak/deterministic at runtime (Emscripten historically returned a fixed sequence unless polyfilled), compounding the 32-bit seed bottleneck. | secondary reports (Ledger blog, community analyses) + Emscripten changelog | Emscripten random_device behavior pre-3.x toolchains | Not directly testable here without building the historical WASM; flagged for further access | نیازمند دسترسی بیشتر (needs_more_access) | low |
| Exploitation occurred in the wild in December 2022 and March 2023 against extension-created wallets. | https://github.com/advisories/GHSA-pm4f-pggw-8jwc | advisory description | Advisory text; corroborated by Ledger's public post-mortem (listed in references) | تأییدشده (confirmed) | high |
| The patched JS bridge falls back in order: window.crypto/msCrypto getRandomValues → Node require('crypto').randomBytes → throw 'No secure random number generator found'. | fixtures/source-snapshots/Random.cpp@d3c2eee16b15.txt | javascript_stir() EM_ASM block, lines ~25-50 | Direct read of post-fix snapshot; logic transcribed and executed under Node.js in experiment E5 (when node available) | تأییدشده (confirmed) | high |
| random_buffer() in the FIXED version emits one byte per uint32 draw (truncating 24 bits per call) — statistically uniform but wasteful; security comes from the CSPRNG backing, not bit-efficiency. | fixtures/source-snapshots/Random.cpp@d3c2eee16b15.txt | javascript_buf(): p[i] = (unsigned char) javascript_random(); | Static reading of the loop body | تأییدشده (confirmed) | high |
| Passing basic statistical uniformity tests does not imply cryptographic security; a 32-bit-seeded MT19937 stream passes chi-square/monobit/correlation checks while having ≤32 bits effective entropy. | this lab's experiments | experiment E3-modelling-stats-deception | Reproducible run: python -m rng_research.cli run-experiments --experiment E3-modelling-stats-deception | تأییدشده (confirmed) | high |
| All browser-extension wallets created with versions 0.0.172–0.0.182 during that period must be treated as potentially compromised; users should upgrade AND move funds. | GHSA advisory + Ledger post-mortem | advisory remediation guidance | Advisory text; operational advice outside this lab's scope to verify individually | تا حدی تأییدشده (partially_confirmed) | medium |

## آزمایش‌ها

### E1-source-snapshot-analysis  · دسته: `real-evidence`
- شناسه اجرا: `E1-source-snapshot-analysis-de94200e` — شروع: 2026-10-12T19:48:19Z — پایان: 2026-10-12T19:48:19Z
- نسخه ابزار: 1.0.0 · پایتون: 3.12.10
- پارامترها: `{}`
- نتایج:
  - `vulnerable_snapshot`:
    - `path`: fixtures/source-snapshots/Random.cpp@69b2da9826df.txt
    - `sha256`: f8dea1b9bd1e7057a0f7166ef372e3b34fc4a96eb7fa9e31bbd137beb8c5aab1
    - `classification`: vulnerable
    - `summary`: VULNERABLE PATTERN: every call constructs a new std::mt19937 seeded with a single 32-bit value. Effective entropy per call is bounded by the seed space (2^32 states), independent of how good the seed source appears.
    - `findings_count`: 8
  - `fixed_snapshot`:
    - `path`: fixtures/source-snapshots/Random.cpp@d3c2eee16b15.txt
    - `sha256`: 609bb7543f9d0d1200f7e62c69c428e805b5e2b4600ece2e60656216ae7f096f
    - `classification`: fixed
    - `summary`: FIXED PATTERN: randomness is delegated to the JS host (crypto.getRandomValues / Node crypto.randomBytes) through Emscripten EM_ASM, with a fail-closed error when no CSPRNG exists.
    - `findings_count`: 11
  - `expected_vuln_sha256`: f8dea1b9bd1e7057a0f7166ef372e3b34fc4a96eb7fa9e31bbd137beb8c5aab1
  - `sha_matches_upstream_record`: True
- منشأ: Inputs are byte-exact copies fetched from trustwallet/wallet-core at commits 69b2da9826df (parent of fix) and d3c2eee16b15 (fix, release 3.1.1). See fixtures/source-snapshots/provenance.json.
- محدودیت: Static analysis of source text only; the historical WASM binary was not rebuilt.
- محدودیت: Classification reflects the RNG layer of wallet-core's WASM port, not every code path of every extension release.

### E2-modelling-seed-collapse  · دسته: `modelling`
- شناسه اجرا: `E2-modelling-seed-collapse-aaa096bb` — شروع: 2026-10-12T19:48:19Z — پایان: 2026-10-12T19:48:20Z
- نسخه ابزار: 1.0.0 · پایتون: 3.12.10
- پارامترها: `{"draws": 40000, "buffer_len": 16}`
- نتایج:
  - `requested_draws`: 40000
  - `unique_seeds`: 40000
  - `duplicate_seed_draws`: 0
  - `distinct_buffers`: 40000
  - `buffer_len`: 16
  - `theoretical_max_distinct_from_32bit_seeds`: 4294967296
  - `same_seed_same_output`: True
  - `birthday_expectation_collisions`: 0.186
- منشأ: Synthetic model; algorithm mirrors wasm/src/Random.cpp@69b2da98 line-for-line (see docs/rng-technical-analysis.md).
- محدودیت: This is a Python MODEL of the C++ mt19937 seeding pattern, not a run of the historical WASM binary.
- محدودیت: Collision counts here measure seed-space collapse (2^32), not mnemonic-level statistics directly.

### E3-modelling-stats-deception  · دسته: `modelling`
- شناسه اجرا: `E3-modelling-stats-deception-d4b3aaa8` — شروع: 2026-10-12T19:48:20Z — پایان: 2026-10-12T19:48:20Z
- نسخه ابزار: 1.0.0 · پایتون: 3.12.10
- پارامترها: `{"bytes": 20000}`
- نتایج:
  - `seeded_with_bits`: 32
  - `stream_length`: 20000
  - `shannon_entropy_bits_per_byte`: 7.9908
  - `statistical_tests` (4 مورد):
    - {"name": "chi_square_frequency", "passed": true, "statistic": 255.36, "p_value": 0.48187}
    - {"name": "monobit", "passed": true, "statistic": 1.37, "p_value": 0.17069}
    - {"name": "serial_correlation_lag1", "passed": true, "statistic": -0.007, "p_value": 0.32075}
    - {"name": "poker", "passed": true, "statistic": 1.2138, "p_value": 1.0}
  - `all_statistical_tests_pass`: True
  - `effective_key_entropy_bits`: 32
- منشأ: Synthetic model of vulnerable per-seed MT19937 stream.
- محدودیت: Passing statistical tests does NOT imply cryptographic security — this experiment demonstrates exactly that gap.
- محدودیت: MODEL output, not historical binary output.

### E4-secure-rng-properties  · دسته: `security-fix`
- شناسه اجرا: `E4-secure-rng-properties-c029fbbb` — شروع: 2026-10-12T19:48:20Z — پایان: 2026-10-12T19:48:20Z
- نسخه ابزار: 1.0.0 · پایتون: 3.12.10
- پارامترها: `{"samples": 20000}`
- نتایج:
  - `provider`: secrets.token_bytes (OS CSPRNG)
  - `length`: 20000
  - `two_draws_differ`: True
  - `shannon_entropy_bits_per_byte`: 7.9915
  - `statistical_tests` (4 مورد):
    - {"name": "chi_square_frequency", "passed": true, "statistic": 235.4688, "p_value": 0.80467}
    - {"name": "monobit", "passed": true, "statistic": 0.425, "p_value": 0.67084}
    - {"name": "serial_correlation_lag1", "passed": true, "statistic": 0.0098, "p_value": 0.16597}
    - {"name": "poker", "passed": true, "statistic": 0.3011, "p_value": 1.0}
- منشأ: Real OS CSPRNG via Python secrets module.
- محدودیت: Statistical tests are necessary-but-not-sufficient evidence for CSPRNG quality.
- محدودیت: Behaviour of the actual patched WASM build inside a browser was not exercised; see node_bridge test below when available.

### E5-node-bridge-check  · دسته: `security-fix`
- شناسه اجرا: `E5-node-bridge-check-03582a27` — شروع: 2026-10-12T19:48:20Z — پایان: 2026-10-12T19:48:21Z
- نسخه ابزار: 1.0.0 · پایتون: 3.12.10
- پارامترها: `{}`
- نتایج:
  - `node_version`: v20.20.2
  - `bridge_ran`: True
  - `two_values_differ`: True
  - `uint32_range_ok`: True
- منشأ: Snippet transcribed from fixtures/source-snapshots/Random.cpp@d3c2eee16b15.txt (EM_ASM block).
- محدودیت: Transcribes the JS logic of the patch; does not execute the compiled WASM itself.

---
این گزارش صرفاً بازسازی فنی/آزمایشگاهی یک آسیب‌پذیری تاریخی است و هیچ گردش‌کار عملیاتی استخراج کلید یا دسترسی به دارایی افراد را شامل نمی‌شود.
